/**
 * Casts the given param to T. Use this instead
 * of casting manually to track such instances. 
 * If things go wrong at least we will know where things
 * went wrong!
 * 
 * @param value this value will returned with desired type
 * @returns the value that you passed in 
 */
export function unsafeCast<T>(value: any): T {
    return value as unknown as T; 
}