import { useCallback, useRef } from "react";

type Ctx = CanvasRenderingContext2D;

interface Vec2 {
  x: number;
  y: number;
}

const CANVAS_WIDTH = 512;
const CANVAS_HEIGHT = 512;
const CENTER: Vec2 = { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT / 2 };
const ROULETTE_IMG_WIDTH = 412;
const ROULETTE_IMG_HEIGHT = 412;
const ROULETEE_IMG_POS = {
  x: (CANVAS_WIDTH - ROULETTE_IMG_WIDTH) / 2,
  y: (CANVAS_HEIGHT - ROULETTE_IMG_HEIGHT) / 2
}
const ROULETTE_IMAGE_RADIUS = (ROULETTE_IMG_WIDTH / 2.0) - 15.0;
const ROULETTE_RADIUS_MID = ROULETTE_IMAGE_RADIUS + 15.0;
const ROULETTE_RADIUS_OUTER = ROULETTE_IMAGE_RADIUS + 30.0;
const BALL_RADIUS = 15.0;

const TAU = Math.PI * 2;

export function RouletteGameComponent() {
  const reqAnimmId = useRef(-1);
  const game = useRef<RouletteGame | null>(null);
  const canvasRef = useCallback((canvasNode: HTMLCanvasElement | null) => {
    if (canvasNode == null) return; // can happen during a hot reload
    const ctx = canvasNode.getContext('2d')!;
    game.current = new RouletteGame();
    let lastRender = performance.now();
    function tick() {
      let diff = performance.now() - lastRender;
      game.current!.onUpdate(ctx, diff);
      reqAnimmId.current = requestAnimationFrame(tick);
      lastRender = performance.now();
    }
    tick();
    return () => {
      cancelAnimationFrame(reqAnimmId.current);
    }
  }, []);

  return (
    <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} />
  )
}

enum RouletteGameStage {
  IDLE,
  ROLLING,
  SETTLED,
}

class RouletteGame {
  private static VALUE_TO_ROTATION = (() => {
    const lookup = new Map<number, number>();
    lookup.set(17, 0.12);
    lookup.set(25, 0.29);
    lookup.set(2, 0.45);
    lookup.set(26, 1.65);
    lookup.set(22, 3.0);
    lookup.set(14, 3.5);
    return lookup;
  })();
  private static INIT_ROT_IMG_VEL = 0.05;
  private static INIT_ROT_BALL_VEL = -0.1;

  constructor(
    private rouletteImg: HTMLImageElement = new Image(),
    private stage: RouletteGameStage = RouletteGameStage.IDLE,
    private imageRotation: number = 0,
    private ballRotation: number = 0,
    private imageRotationVel: number = RouletteGame.INIT_ROT_IMG_VEL,
    private ballRotationVel: number = RouletteGame.INIT_ROT_BALL_VEL,
    private settledOn: number | null = null,
    private timer: Timer| null = null,
  ) {
    rouletteImg.src = 'roulette.png';
   
    this.startRolling();
    setTimeout(() => {
      this.settleRoll(22);
    }, 3000);

  }

  onUpdate(ctx: Ctx, diff: number) {
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    this.drawRoulette(ctx);
    this.drawBall(ctx, pointOnCircle(CENTER, ROULETTE_RADIUS_MID, this.ballRotation), 15.0);

    switch (this.stage) {
      case RouletteGameStage.IDLE: {
        break;
      }
      case RouletteGameStage.ROLLING: {
        this.imageRotation += this.imageRotationVel;
        this.ballRotation += this.ballRotationVel;
        break;
      }
      case RouletteGameStage.SETTLED: {
        const timer = this.timer!;
        if (timer.tick(diff))
          break;
        this.ballRotationVel = lerp(RouletteGame.INIT_ROT_BALL_VEL, 0, timer.percent_complete());
        this.imageRotationVel = lerp(RouletteGame.INIT_ROT_IMG_VEL, 0, timer.percent_complete());
        this.imageRotation += this.imageRotationVel;
        this.ballRotation += this.ballRotationVel;
        break;
      }
    }

    this.imageRotation %= TAU;
    this.ballRotation %= TAU;

  }

  startRolling() {
    this.stage = RouletteGameStage.ROLLING;
    this.timer = new Timer(3000);
    this.imageRotationVel = RouletteGame.INIT_ROT_IMG_VEL;
    this.ballRotationVel = RouletteGame.INIT_ROT_BALL_VEL;
  }

  settleRoll(value: number) {
    this.stage = RouletteGameStage.SETTLED;
    this.settledOn = value;
  }

  private drawRoulette(ctx: Ctx) {
    { // draw "outer" ring
      ctx.fillStyle = "#3e2723";
      ctx.beginPath();
      ctx.arc(CENTER.x, CENTER.y, ROULETTE_RADIUS_OUTER, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#2d1c19";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(CENTER.x, CENTER.y, ROULETTE_RADIUS_OUTER + 2.0, 0, TAU);
      ctx.stroke();
    }
    { // draw the roulette image
      ctx.save();
      ctx.translate(CENTER.x, CENTER.y);
      ctx.rotate(this.imageRotation);
      ctx.translate(-CENTER.x, -CENTER.y);
      ctx.drawImage(
        this.rouletteImg,
        ROULETEE_IMG_POS.x,
        ROULETEE_IMG_POS.y,
        ROULETTE_IMG_WIDTH,
        ROULETTE_IMG_HEIGHT,
      );
      ctx.restore();
    }


  }

  private drawBall(ctx: Ctx, pos: Vec2, radius: number) {
    // gradient makes it look like its rotating
    const gradient = ctx.createRadialGradient(pos.x, pos.y, radius, 0, 0, 250);
    gradient.addColorStop(0, "#666");
    gradient.addColorStop(1, "#999");
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, radius, 0, TAU)
    ctx.fill();
  }



}

function pointOnCircle(center: Vec2, radius: number, radians: number): Vec2 {
  return {
    x: center.x + radius * Math.cos(radians),
    y: center.y + radius * Math.sin(radians)
  }
}

class Timer {
  private elapsed: number;
  constructor(private duration: number) {
    this.elapsed = 0;
  }
  public tick(dt: number) {
    this.elapsed += dt;
    return this.elapsed > this.duration;
  }
  public percent_complete(): number {
    return this.elapsed /this.duration; 
  }
}


function lerp(
  value_1: number,
  value_2: number,
  t: number,
): number {
  return (1.0 - t) * value_1 + t * value_2;
}